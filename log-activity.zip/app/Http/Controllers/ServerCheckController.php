<?php

namespace App\Http\Controllers;

use App\Models\ServerCheck;
use App\Models\ServerCheckEntry;
use App\Support\Signature;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class ServerCheckController extends Controller
{
    public function index(Request $request)
    {
        $bulan = $request->query('bulan');

        $checks = ServerCheck::query()
            ->with('entries.parafUser')
            ->bulan($bulan)
            ->orderByDesc('check_date')
            ->paginate(15)
            ->withQueryString();

        return view('server-checks.index', [
            'checks' => $checks,
            'bulan' => $bulan,
            'slots' => ServerCheckEntry::SLOTS,
        ]);
    }

    /**
     * Buat form untuk 1 tanggal (item diambil dari master item aktif), lalu langsung ke halaman isi.
     */
    public function store(Request $request)
    {
        abort_unless($request->user()->isStaff(), 403, 'Hanya Staf yang bisa membuat form kontrol server.');

        $data = $request->validate(
            ['check_date' => ['required', 'date']],
            [],
            ['check_date' => 'Tanggal']
        );

        $date = Carbon::parse($data['check_date'])->toDateString();

        if ($existing = ServerCheck::whereDate('check_date', $date)->first()) {
            return redirect()
                ->route('server-checks.edit', $existing)
                ->with('success', 'Form tanggal ini sudah ada, silakan lanjut mengisi.');
        }

        $check = ServerCheck::createForDate($date, auth()->id());

        if ($check->entries()->count() === 0) {
            $check->delete();

            return back()->with('error', 'Belum ada item pemeriksaan aktif. Minta Admin menambahkan di menu "Item Kontrol Server".');
        }

        return redirect()
            ->route('server-checks.edit', $check)
            ->with('success', 'Form berhasil dibuat. Silakan isi pemeriksaan.');
    }

    public function edit(ServerCheck $server_check)
    {
        $server_check->load('entries.parafUser');

        return view('server-checks.edit', [
            'check' => $server_check,
            'groups' => $server_check->entries->groupBy('section_code'),
            'slots' => ServerCheckEntry::SLOTS,
        ]);
    }

    public function update(Request $request, ServerCheck $server_check)
    {
        // Paraf = tanda tangan staf yang mengisi, jadi hanya Staf yang boleh mengisi form.
        abort_unless($request->user()->isStaff(), 403, 'Hanya Staf yang bisa mengisi form kontrol server.');

        $rules = ['entries' => ['nullable', 'array']];

        foreach (array_keys(ServerCheckEntry::SLOTS) as $n) {
            $rules["entries.*.c{$n}"] = ['nullable', Rule::in(ServerCheckEntry::CONDITIONS)];
            $rules["entries.*.n{$n}"] = ['nullable', 'string', 'max:2000'];
        }

        $request->validate($rules);

        $input = $request->input('entries', []);
        $userId = auth()->id();
        $changed = 0;

        DB::transaction(function () use ($server_check, $input, $userId, &$changed) {
            foreach ($server_check->entries as $entry) {
                $row = $input[$entry->id] ?? null;

                if (! is_array($row)) {
                    continue;
                }

                $dirty = false;

                // Hanya kolom yang dikirim form yang diproses (keterangan gabungan hanya dikirim di baris pertama bagian).
                foreach (array_keys($row) as $key) {
                    if (! preg_match('/^[cn][1-3]$/', $key)) {
                        continue;
                    }

                    $value = trim((string) ($row[$key] ?? ''));
                    $value = $value === '' ? null : $value;

                    if ((string) $entry->{$key} !== (string) $value) {
                        $entry->{$key} = $value;
                        $dirty = true;
                    }
                }

                // Paraf otomatis = staf yang terakhir mengubah baris ini.
                if ($dirty) {
                    $entry->paraf_by = $userId;
                    $entry->save();
                    $changed++;
                }
            }

            // Supaya laporan bulanan tahu data bulan ini berubah (lihat MonthlyReport::snapshotFor).
            if ($changed > 0) {
                $server_check->touch();
            }
        });

        // Isi form berubah -> tanda tangan lama tidak berlaku lagi (harus ditandatangani ulang).
        $signatureReset = $changed > 0 && $server_check->isSigned();

        if ($signatureReset) {
            $server_check->clearSignature();
        }

        return redirect()
            ->route('server-checks.edit', $server_check)
            ->with('success', $changed > 0
                ? 'Form berhasil disimpan.' . ($signatureReset ? ' Tanda tangan Group Head dihapus karena isi berubah, Group Head perlu menandatangani ulang.' : '')
                : 'Tidak ada perubahan.');
    }

    /**
     * Tanda tangani form. HANYA Group Head. Tanda tangan diambil dari Profil dan disalin sebagai snapshot.
     */
    public function sign(Request $request, ServerCheck $server_check)
    {
        $user = $request->user();

        abort_unless($user->isGroupHead(), 403, 'Hanya Group Head yang bisa menandatangani form kontrol server.');

        $server_check->load('entries');

        if (array_sum($server_check->filledCounts()) === 0) {
            return back()->with('error', 'Form masih kosong, isi pemeriksaan dulu sebelum ditandatangani.');
        }

        if (! Signature::exists($user->signature)) {
            return back()->with('error', 'Tanda tangan Anda belum ada. Isi dulu di menu Profil Saya, lalu tanda tangani lagi.');
        }

        // Ganti tanda tangan sebelumnya (kalau ada) dengan yang baru.
        Signature::delete($server_check->signed_signature);

        $server_check->timestamps = false; // tanda tangan bukan perubahan data
        $server_check->update([
            'signed_by' => $user->id,
            'signed_name' => $user->name,
            'signed_signature' => Signature::snapshot($user->signature),
            'signed_at' => now(),
        ]);
        $server_check->timestamps = true;

        return back()->with('success', 'Form berhasil ditandatangani.');
    }

    /**
     * Batalkan tanda tangan: hanya Group Head.
     */
    public function unsign(Request $request, ServerCheck $server_check)
    {
        abort_unless(
            $request->user()->isGroupHead(),
            403,
            'Hanya Group Head yang bisa membatalkan tanda tangan form kontrol server.'
        );

        $server_check->clearSignature();

        return back()->with('success', 'Tanda tangan form dibatalkan.');
    }

    public function destroy(ServerCheck $server_check)
    {
        Signature::delete($server_check->signed_signature);
        $server_check->delete();

        return redirect()
            ->route('server-checks.index')
            ->with('success', 'Form kontrol berhasil dihapus.');
    }

    /**
     * Download PDF 1 hari (landscape, identik dengan lampiran di laporan bulanan).
     */
    public function pdf(ServerCheck $server_check)
    {
        return $this->respond($server_check, false);
    }

    /**
     * Pratinjau PDF langsung di browser (tanpa download).
     */
    public function preview(ServerCheck $server_check)
    {
        return $this->respond($server_check, true);
    }

    protected function respond(ServerCheck $check, bool $inline)
    {
        @set_time_limit(120);

        $check->load('entries.parafUser');
        $checks = collect([$check]);

        $pdf = Pdf::loadView('server-checks.sheet', [
            'checks' => $checks,
            'sigs' => ServerCheck::signatureMap($checks),
        ])->setPaper('a4', 'landscape');

        $filename = 'kontrol-server-jaringan-' . $check->check_date->format('Ymd') . '.pdf';

        return response($pdf->output(), 200, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => ($inline ? 'inline' : 'attachment') . '; filename="' . $filename . '"',
        ]);
    }
}
