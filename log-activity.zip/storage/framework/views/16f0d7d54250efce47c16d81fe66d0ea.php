<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard Log Isu & Permintaan'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/apex-charts/apex-charts.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    
    <form method="GET" action="<?php echo e(route('dashboard')); ?>" class="row g-3 mb-4">
        <div class="col-auto">
            <input type="text" name="bulan" value="<?php echo e($bulan); ?>" class="form-control"
                   placeholder='Filter bulan, contoh: "September 2026"'>
        </div>
        <div class="col-auto">
            <button class="btn btn-primary" type="submit">
                <i class="ti tabler-filter me-1"></i> Filter
            </button>
        </div>
        <?php if($bulan): ?>
            <div class="col-auto">
                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-outline-secondary">Reset</a>
            </div>
        <?php endif; ?>
    </form>

    
    <h6 class="text-uppercase text-body-secondary mb-3">Log Isu</h6>
    <div class="row g-4 mb-4">
        <div class="col-sm-6 col-lg-3">
            <div class="card h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1">Total Isu</p>
                        <h4 class="mb-0"><?php echo e($issueCounts['total']); ?></h4>
                    </div>
                    <span class="avatar-initial rounded bg-label-primary p-3">
                        <i class="ti tabler-alert-circle icon-md"></i>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3">
            <div class="card h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1">Isu Open</p>
                        <h4 class="mb-0"><?php echo e($issueCounts['open']); ?></h4>
                    </div>
                    <span class="avatar-initial rounded bg-label-danger p-3">
                        <i class="ti tabler-circle-dot icon-md"></i>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3">
            <div class="card h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1">Isu In Progress</p>
                        <h4 class="mb-0"><?php echo e($issueCounts['in_progress']); ?></h4>
                    </div>
                    <span class="avatar-initial rounded bg-label-warning p-3">
                        <i class="ti tabler-loader-2 icon-md"></i>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3">
            <div class="card h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1">Isu Done</p>
                        <h4 class="mb-0"><?php echo e($issueCounts['done']); ?></h4>
                    </div>
                    <span class="avatar-initial rounded bg-label-success p-3">
                        <i class="ti tabler-circle-check icon-md"></i>
                    </span>
                </div>
            </div>
        </div>
    </div>

    
    <h6 class="text-uppercase text-body-secondary mb-3">Log Permintaan</h6>
    <div class="row g-4 mb-4">
        <div class="col-sm-6 col-lg-3">
            <div class="card h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1">Total Permintaan</p>
                        <h4 class="mb-0"><?php echo e($requestCounts['total']); ?></h4>
                    </div>
                    <span class="avatar-initial rounded bg-label-primary p-3">
                        <i class="ti tabler-clipboard-list icon-md"></i>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3">
            <div class="card h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1">Permintaan Open</p>
                        <h4 class="mb-0"><?php echo e($requestCounts['open']); ?></h4>
                    </div>
                    <span class="avatar-initial rounded bg-label-danger p-3">
                        <i class="ti tabler-circle-dot icon-md"></i>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3">
            <div class="card h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1">Permintaan In Progress</p>
                        <h4 class="mb-0"><?php echo e($requestCounts['in_progress']); ?></h4>
                    </div>
                    <span class="avatar-initial rounded bg-label-warning p-3">
                        <i class="ti tabler-loader-2 icon-md"></i>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3">
            <div class="card h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1">Permintaan Done</p>
                        <h4 class="mb-0"><?php echo e($requestCounts['done']); ?></h4>
                    </div>
                    <span class="avatar-initial rounded bg-label-success p-3">
                        <i class="ti tabler-circle-check icon-md"></i>
                    </span>
                </div>
            </div>
        </div>
    </div>

    
    <h6 class="text-uppercase text-body-secondary mb-3">Permohonan Reset</h6>
    <div class="row g-4 mb-4">
        <div class="col-sm-6 col-lg-3">
            <div class="card h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1">Total Permohonan</p>
                        <h4 class="mb-0"><?php echo e($resetRequestCounts['total']); ?></h4>
                    </div>
                    <span class="avatar-initial rounded bg-label-primary p-3">
                        <i class="ti tabler-lock-open icon-md"></i>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3">
            <div class="card h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1">Permohonan Open</p>
                        <h4 class="mb-0"><?php echo e($resetRequestCounts['open']); ?></h4>
                    </div>
                    <span class="avatar-initial rounded bg-label-danger p-3">
                        <i class="ti tabler-circle-dot icon-md"></i>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3">
            <div class="card h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1">Permohonan In Progress</p>
                        <h4 class="mb-0"><?php echo e($resetRequestCounts['in_progress']); ?></h4>
                    </div>
                    <span class="avatar-initial rounded bg-label-warning p-3">
                        <i class="ti tabler-loader-2 icon-md"></i>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3">
            <div class="card h-100">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <p class="mb-1">Permohonan Done</p>
                        <h4 class="mb-0"><?php echo e($resetRequestCounts['done']); ?></h4>
                    </div>
                    <span class="avatar-initial rounded bg-label-success p-3">
                        <i class="ti tabler-circle-check icon-md"></i>
                    </span>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card mb-4">
        <div class="card-header">
            <h6 class="mb-0">Tren Isu & Permintaan — 6 Bulan Terakhir</h6>
        </div>
        <div class="card-body">
            <div id="trendChart"></div>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h6 class="mb-0">Isu berstatus Open / In Progress terbaru</h6>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Kategori</th>
                    <th>Isu</th>
                    <th>Pemohon</th>
                    <th>Status</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $latestOpenIssues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($issue->occurred_at->format('d/m/Y')); ?></td>
                        <td><?php echo e($issue->category); ?></td>
                        <td><?php echo e($issue->title); ?></td>
                        <td><?php echo e($issue->requester); ?></td>
                        <td>
                            <span class="badge bg-label-<?php echo e($issue->status->badgeColor()); ?>">
                                <?php echo e($issue->status->value); ?>

                            </span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-body-secondary py-4">
                            Tidak ada isu Open / In Progress saat ini.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/vendor/libs/apex-charts/apexcharts.js')); ?>"></script>
    <script>
        (function () {
            const trendChartEl = document.querySelector('#trendChart');
            if (!trendChartEl || typeof ApexCharts === 'undefined') return;

            // Ambil warna teks & garis grid mengikuti tema aktif (light/dark)
            // supaya label sumbu & legend tetap terbaca, bukan hardcode hitam.
            function getChartTextColor() {
                const isDark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
                return isDark ? '#adb0bb' : '#697a8d';
            }
            function getChartGridColor() {
                const isDark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
                return isDark ? 'rgba(255, 255, 255, 0.12)' : 'rgba(50, 71, 92, 0.12)';
            }

            const options = {
                chart: {
                    type: 'bar',
                    height: 320,
                    toolbar: { show: false },
                    fontFamily: 'inherit',
                    foreColor: getChartTextColor(),
                },
                series: [
                    { name: 'Isu', data: <?php echo json_encode($issueTrend, 15, 512) ?> },
                    { name: 'Permintaan', data: <?php echo json_encode($requestTrend, 15, 512) ?> },
                    { name: 'Permohonan Reset', data: <?php echo json_encode($resetRequestTrend, 15, 512) ?> },
                ],
                xaxis: {
                    categories: <?php echo json_encode($trendLabels, 15, 512) ?>,
                    labels: { style: { colors: getChartTextColor() } },
                    axisBorder: { color: getChartGridColor() },
                    axisTicks: { color: getChartGridColor() },
                },
                yaxis: {
                    forceNiceScale: true,
                    labels: {
                        formatter: (val) => Math.round(val),
                        style: { colors: getChartTextColor() },
                    },
                },
                colors: ['#696CFF', '#03C3EC', '#FFAB00'],
                plotOptions: {
                    bar: { borderRadius: 6, columnWidth: '45%' },
                },
                dataLabels: { enabled: false },
                legend: {
                    position: 'top',
                    labels: { colors: getChartTextColor() },
                },
                grid: {
                    strokeDashArray: 4,
                    borderColor: getChartGridColor(),
                },
                tooltip: {
                    theme: document.documentElement.getAttribute('data-bs-theme') === 'dark' ? 'dark' : 'light',
                },
            };

            const trendChart = new ApexCharts(trendChartEl, options);
            trendChart.render();

            // Ikuti perubahan tema secara langsung saat toggle Light/Dark/System
            document.querySelectorAll('[data-bs-theme-value]').forEach((toggle) => {
                toggle.addEventListener('click', () => {
                    setTimeout(() => {
                        trendChart.updateOptions({
                            chart: { foreColor: getChartTextColor() },
                            xaxis: {
                                labels: { style: { colors: getChartTextColor() } },
                                axisBorder: { color: getChartGridColor() },
                                axisTicks: { color: getChartGridColor() },
                            },
                            yaxis: { labels: { style: { colors: getChartTextColor() } } },
                            legend: { labels: { colors: getChartTextColor() } },
                            grid: { borderColor: getChartGridColor() },
                            tooltip: { theme: document.documentElement.getAttribute('data-bs-theme') === 'dark' ? 'dark' : 'light' },
                        });
                    }, 50);
                });
            });
        })();
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\log-activity\resources\views/dashboard.blade.php ENDPATH**/ ?>