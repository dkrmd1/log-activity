<?php $__env->startSection('title', 'Log Isu'); ?>
<?php $__env->startSection('page-title', 'Log Isu'); ?>

<?php $__env->startSection('content'); ?>

    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('issues.index')); ?>" class="row g-3 align-items-end">
                <div class="col-sm-6 col-md-3">
                    <label class="form-label">Cari Isu</label>
                    <input type="text" name="cari" value="<?php echo e($filters['cari'] ?? ''); ?>" class="form-control" placeholder="Judul isu...">
                </div>
                <div class="col-sm-6 col-md-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="">Semua Status</option>
                        <?php $__currentLoopData = $statusOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($status); ?>" <?php if(($filters['status'] ?? '') === $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-sm-6 col-md-3">
                    <label class="form-label">Bulan</label>
                    <input type="text" name="bulan" value="<?php echo e($filters['bulan'] ?? ''); ?>" class="form-control" placeholder='contoh: "September 2026"'>
                </div>
                <div class="col-sm-6 col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-primary flex-grow-1">
                        <i class="ti tabler-filter me-1"></i> Filter
                    </button>
                    <a href="<?php echo e(route('issues.index')); ?>" class="btn btn-outline-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h6 class="mb-0">Daftar Isu</h6>
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('issues.export.excel', $filters)); ?>" class="btn btn-outline-success btn-sm">
                    <i class="ti tabler-file-spreadsheet me-1"></i> Export Excel
                </a>
                <a href="<?php echo e(route('issues.export.pdf', $filters)); ?>" class="btn btn-outline-danger btn-sm">
                    <i class="ti tabler-file-type-pdf me-1"></i> Export PDF
                </a>
                <a href="<?php echo e(route('issues.create')); ?>" class="btn btn-primary btn-sm">
                    <i class="ti tabler-plus me-1"></i> Tambah Isu
                </a>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal Terjadi</th>
                    <th>Kategori</th>
                    <th>Isu</th>
                    <th>Pemohon</th>
                    <th>Status</th>
                    <th class="text-end">Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration + ($issues->currentPage() - 1) * $issues->perPage()); ?></td>
                        <td><?php echo e($issue->occurred_at->format('d/m/Y')); ?></td>
                        <td><?php echo e($issue->category); ?></td>
                        <td><?php echo e(\Illuminate\Support\Str::limit($issue->title, 40)); ?></td>
                        <td><?php echo e($issue->requester); ?></td>
                        <td>
                            <span class="badge bg-label-<?php echo e($issue->status->badgeColor()); ?>">
                                <?php echo e($issue->status->value); ?>

                            </span>
                        </td>
                        <td class="text-end">
                            <a href="<?php echo e(route('issues.show', $issue)); ?>" class="btn btn-icon btn-text-secondary" title="Lihat">
                                <i class="ti tabler-eye"></i>
                            </a>
                            <a href="<?php echo e(route('issues.edit', $issue)); ?>" class="btn btn-icon btn-text-secondary" title="Edit">
                                <i class="ti tabler-edit"></i>
                            </a>
                            <form action="<?php echo e(route('issues.destroy', $issue)); ?>" method="POST" class="d-inline"
                                  onsubmit="return confirm('Yakin hapus isu ini?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-icon btn-text-danger" title="Hapus">
                                    <i class="ti tabler-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-body-secondary py-4">
                            Belum ada data isu. Klik "Tambah Isu" untuk mulai mencatat.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($issues->hasPages()): ?>
            <div class="card-footer">
                <?php echo e($issues->links('pagination::bootstrap-5')); ?>

            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\log-activity\resources\views/issues/index.blade.php ENDPATH**/ ?>