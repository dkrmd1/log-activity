
<?php
    $slots = \App\Models\ServerCheckEntry::SLOTS;
    $sigs = $sigs ?? [];
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Kontrol Server &amp; Jaringan</title>
    <style>
        /* Warna header: ubah di sini kalau berbeda dengan form asli */
        @page { margin: 26pt 28pt 34pt 28pt; counter-increment: page; }

        body {
            font-family: "Helvetica", sans-serif;
            font-size: 7pt;
            color: #000;
            <?php if(!empty($showPageNumbers) && !empty($pageStart)): ?> counter-reset: page <?php echo e($pageStart - 1); ?>; <?php endif; ?>
        }

        table.top { width: 100%; border-collapse: collapse; margin-bottom: 4pt; }
        table.top td { border: none; padding: 0; vertical-align: bottom; }
        td.ttl { font-size: 15pt; font-weight: bold; color: #808080; }
        td.tgl { text-align: right; font-size: 8.5pt; }

        table.form { width: 100%; border-collapse: collapse; table-layout: fixed; }
        table.form th, table.form td { border: 0.5pt solid #000; padding: 1.4pt 3pt; vertical-align: middle; }
        table.form tr { page-break-inside: avoid; }

        table.form tr.sp th { border: none; padding: 0; height: 0; line-height: 0; font-size: 0; background: none; }
        th.red { background: #FF4B4B; color: #fff; font-weight: bold; font-size: 8pt; text-align: center; }
        th.yel { background: #FFFF00; color: #000; font-weight: bold; font-size: 7pt; text-align: center; }

        td.letter { text-align: center; font-size: 6.5pt; }
        td.sec-title { font-weight: bold; text-decoration: underline; font-size: 7.5pt; }
        td.num { text-align: center; font-size: 6pt; }
        td.item { text-align: left; }
        td.cond { text-align: center; }
        td.note { text-align: left; vertical-align: top; font-size: 6.5pt; line-height: 1.35; }
        td.paraf { text-align: center; padding-top: 0.6pt; padding-bottom: 0.6pt; }
        td.paraf .pf { height: 12pt; overflow: hidden; }
        td.paraf img { height: 12pt; }
        td.paraf .ini { font-size: 6pt; }

        /* Blok tanda tangan penanggung jawab (kanan bawah, di bawah tabel halaman terakhir) */
        table.signoff { width: 100%; border-collapse: collapse; margin-top: 10pt; page-break-inside: avoid; }
        table.signoff td { border: none; padding: 0; vertical-align: top; }
        td.so { width: 24%; text-align: center; font-size: 8pt; }
        .so-sig { height: 42pt; }
        .so-sig img { height: 40pt; }

        footer { position: fixed; bottom: -22pt; left: 0; right: 0; text-align: right; font-size: 7pt; color: #666; }
        .page-num:before { content: counter(page); }
    </style>
</head>
<body>

<?php if(!empty($showPageNumbers) && !empty($pageStart)): ?>
    <footer>Halaman <span class="page-num"></span><?php if(!empty($totalPages)): ?> dari <?php echo e($totalPages); ?><?php endif; ?></footer>
<?php endif; ?>

<?php
    $pageNo = 0;
?>

<?php $__currentLoopData = $checks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <?php
        $pages = \App\Support\ServerCheckLayout::pages($check->entries);
        $lastPage = count($pages) - 1;
        $so = $check->signoff;
    ?>
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pi => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div <?php if($pageNo++ > 0): ?> style="page-break-before: always;" <?php endif; ?>>

            <table class="top">
                <tr>
                    <td class="ttl">KONTROL SERVER &amp; JARINGAN</td>
                    <td class="tgl">Tanggal, <?php echo e($check->date_label); ?></td>
                </tr>
            </table>

            <?php if(count($page) > 0): ?>
            <table class="form">
                <thead>
                
                <tr class="sp">
                    <th style="width:3.5%"></th>
                    <th style="width:2%"></th>
                    <th style="width:27%"></th>
                    <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th style="width:4.2%"></th>
                        <th style="width:15.4%"></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th style="width:8.7%"></th>
                </tr>
                <tr>
                    <th class="red" rowspan="2">No</th>
                    <th class="red" rowspan="2" colspan="2">Item</th>
                    <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="red" colspan="2"><?php echo e($label); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th class="red">&nbsp;</th>
                </tr>
                <tr>
                    <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="yel">Kondisi</th>
                        <th class="yel">Keterangan</th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th class="yel">Paraf</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $rows = $block['rows'];
                        $count = count($rows);
                        $first = $rows[0];
                    ?>
                    <tr>
                        <td class="letter" rowspan="<?php echo e($count + 1); ?>"><?php echo e($block['code']); ?></td>
                        <td class="sec-title" colspan="9"><?php echo e($block['title']); ?></td>
                    </tr>
                    <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ri => $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="num"><?php echo e($e->item_no); ?></td>
                            <td class="item"><?php echo e($e->item_name); ?></td>
                            <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="cond"><?php echo e($e->{'c' . $n}); ?></td>
                                <?php if($block['merge']): ?>
                                    <?php if($ri === 0): ?>
                                        <td class="note" rowspan="<?php echo e($count); ?>"><?php echo $block['continued'] ? '' : nl2br(e($first->{'n' . $n})); ?></td>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <td class="note"><?php echo nl2br(e($e->{'n' . $n})); ?></td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td class="paraf">
                                <div class="pf">
                                    <?php if($e->paraf_by && !empty($sigs[$e->paraf_by])): ?>
                                        <img src="<?php echo e($sigs[$e->paraf_by]); ?>" alt="">
                                    <?php elseif($e->paraf_by && $e->parafUser): ?>
                                        <span class="ini"><?php echo e($e->parafUser->name); ?></span>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php endif; ?>

            <?php if($pi === $lastPage): ?>
                <table class="signoff">
                    <tr>
                        <td></td>
                        <td class="so">
                            <div>Tanggal, <?php echo e($check->date_label); ?></div>
                            <div class="so-sig">
                                <?php if(!empty($so['uri'])): ?>
                                    <img src="<?php echo e($so['uri']); ?>" alt="">
                                <?php endif; ?>
                            </div>
                            <div><?php echo e($so['name']); ?></div>
                        </td>
                    </tr>
                </table>
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\log-activity\resources\views/server-checks/sheet.blade.php ENDPATH**/ ?>