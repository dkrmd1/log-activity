<?php $__env->startSection('title', 'Log Backup'); ?>
<?php $__env->startSection('page-title', 'Log Backup Data'); ?>

<?php $__env->startSection('content'); ?>

    
    <div class="card mb-4">
        <div class="card-header">
            <h6 class="mb-0">Status Backup &mdash; <?php echo e($summaryLabel); ?></h6>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th style="width:60px">No</th>
                    <th>Jenis</th>
                    <th>Tanggal</th>
                    <th>Jam</th>
                    <th>Status</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $jenisOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php ($last = $latestPerJenis->get($jenis)); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($jenis); ?></td>
                        <td><?php echo e($last?->date_label ?? '-'); ?></td>
                        <td><?php echo e($last?->time_label ?? '-'); ?></td>
                        <td>
                            <?php if($last): ?>
                                <span class="badge bg-label-success">Sudah</span>
                            <?php else: ?>
                                <span class="badge bg-label-secondary">Belum</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('backup-logs.index')); ?>" class="row g-3 align-items-end">
                <div class="col-sm-6 col-md-3">
                    <label class="form-label">Cari</label>
                    <input type="text" name="cari" value="<?php echo e($filters['cari'] ?? ''); ?>" class="form-control" placeholder="Jenis / keterangan...">
                </div>
                <div class="col-sm-6 col-md-3">
                    <label class="form-label">Jenis</label>
                    <select name="jenis" class="form-select">
                        <option value="">Semua Jenis</option>
                        <?php $__currentLoopData = $jenisOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($jenis); ?>" <?php if(($filters['jenis'] ?? '') === $jenis): echo 'selected'; endif; ?>><?php echo e($jenis); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-sm-6 col-md-3">
                    <label class="form-label">Bulan</label>
                    <input type="text" name="bulan" value="<?php echo e($filters['bulan'] ?? ''); ?>" class="form-control" placeholder='contoh: "September 2026"'>
                </div>
                <div class="col-sm-6 col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-primary flex-grow-1">
                        <i class="ti tabler-filter me-1"></i> Filter
                    </button>
                    <a href="<?php echo e(route('backup-logs.index')); ?>" class="btn btn-outline-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h6 class="mb-0">Riwayat Backup</h6>
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('backup-logs.export.excel', $filters)); ?>" class="btn btn-outline-success btn-sm">
                    <i class="ti tabler-file-spreadsheet me-1"></i> Export Excel
                </a>
                <a href="<?php echo e(route('backup-logs.export.pdf', $filters)); ?>" class="btn btn-outline-danger btn-sm">
                    <i class="ti tabler-file-type-pdf me-1"></i> Export PDF
                </a>
                <a href="<?php echo e(route('backup-logs.create')); ?>" class="btn btn-primary btn-sm">
                    <i class="ti tabler-plus me-1"></i> Catat Backup
                </a>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th>No</th>
                    <th>Jenis</th>
                    <th>Tanggal</th>
                    <th>Jam</th>
                    <th>Keterangan</th>
                    <th>Dicatat Oleh</th>
                    <th class="text-end">Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $backupLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration + ($backupLogs->currentPage() - 1) * $backupLogs->perPage()); ?></td>
                        <td><?php echo e($item->jenis); ?></td>
                        <td><?php echo e($item->date_label); ?></td>
                        <td><?php echo e($item->time_label); ?></td>
                        <td><?php echo e($item->notes ?: '-'); ?></td>
                        <td><?php echo e($item->user?->name ?? '-'); ?></td>
                        <td class="text-end">
                            <a href="<?php echo e(route('backup-logs.edit', $item)); ?>" class="btn btn-icon btn-text-secondary" title="Edit">
                                <i class="ti tabler-edit"></i>
                            </a>
                            <form action="<?php echo e(route('backup-logs.destroy', $item)); ?>" method="POST" class="d-inline"
                                  onsubmit="return confirm('Yakin hapus catatan backup ini?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-icon btn-text-danger" title="Hapus">
                                    <i class="ti tabler-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-body-secondary py-4">
                            Belum ada catatan backup. Klik "Catat Backup" untuk mulai mencatat.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($backupLogs->hasPages()): ?>
            <div class="card-footer">
                <?php echo e($backupLogs->links('pagination::bootstrap-5')); ?>

            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\log-activity\resources\views/backup-logs/index.blade.php ENDPATH**/ ?>