<?php $__env->startSection('title', 'Item Kontrol Server'); ?>
<?php $__env->startSection('page-title', 'Item Kontrol Server & Jaringan'); ?>

<?php $__env->startSection('content'); ?>

    <div class="alert alert-info">
        Atur bagian (A, B, C, ...) dan item pemeriksaan pada form <strong>Kontrol Server &amp; Jaringan</strong>.
        Perubahan hanya berlaku untuk <strong>form baru</strong>; form yang sudah dibuat tidak berubah.
        Item yang dinonaktifkan tidak muncul di form baru. Jika "Keterangan digabung" aktif, kolom Keterangan
        satu bagian dijadikan 1 sel besar (seperti bagian A).
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($err); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header"><h6 class="mb-0">Tambah Bagian Baru</h6></div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('control-items.sections.store')); ?>" class="row g-2 align-items-end">
                <?php echo csrf_field(); ?>
                <div class="col-sm-2">
                    <label class="form-label">Kode</label>
                    <input type="text" name="code" value="<?php echo e(old('code')); ?>" maxlength="5" class="form-control <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="D">
                    <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-sm-6">
                    <label class="form-label">Judul bagian</label>
                    <input type="text" name="title" value="<?php echo e(old('title')); ?>" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Pemeriksaan ...">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-sm-2">
                    <div class="form-check mb-2">
                        <input type="checkbox" name="merge_notes" value="1" id="newMerge" class="form-check-input">
                        <label for="newMerge" class="form-check-label">Keterangan digabung</label>
                    </div>
                </div>
                <div class="col-sm-2">
                    <button type="submit" class="btn btn-primary w-100"><i class="ti tabler-plus me-1"></i> Tambah</button>
                </div>
            </form>
        </div>
    </div>

    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-4">
            <div class="card-header">
                <form method="POST" action="<?php echo e(route('control-items.sections.update', $section)); ?>" class="row g-2 align-items-end">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="col-sm-1">
                        <label class="form-label small">Kode</label>
                        <input type="text" name="code" value="<?php echo e($section->code); ?>" maxlength="5" class="form-control form-control-sm">
                    </div>
                    <div class="col-sm-5">
                        <label class="form-label small">Judul bagian</label>
                        <input type="text" name="title" value="<?php echo e($section->title); ?>" class="form-control form-control-sm">
                    </div>
                    <div class="col-sm-1">
                        <label class="form-label small">Urutan</label>
                        <input type="number" name="sort_order" value="<?php echo e($section->sort_order); ?>" class="form-control form-control-sm">
                    </div>
                    <div class="col-sm-2">
                        <div class="form-check mb-1">
                            <input type="checkbox" name="merge_notes" value="1" id="merge<?php echo e($section->id); ?>" class="form-check-input" <?php if($section->merge_notes): echo 'checked'; endif; ?>>
                            <label for="merge<?php echo e($section->id); ?>" class="form-check-label small">Keterangan digabung</label>
                        </div>
                    </div>
                    <div class="col-sm-3 d-flex gap-2">
                        <button type="submit" class="btn btn-sm btn-outline-primary"><i class="ti tabler-device-floppy me-1"></i> Simpan</button>
                        <button type="submit" form="delSection<?php echo e($section->id); ?>" class="btn btn-sm btn-outline-danger"
                                onclick="return confirm('Hapus bagian <?php echo e($section->code); ?> beserta semua itemnya? (Form yang sudah dibuat tidak terpengaruh)');">
                            <i class="ti tabler-trash"></i>
                        </button>
                    </div>
                </form>
                <form id="delSection<?php echo e($section->id); ?>" method="POST" action="<?php echo e(route('control-items.sections.destroy', $section)); ?>" class="d-none">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                </form>
            </div>

            <div class="table-responsive">
                <table class="table table-sm mb-0">
                    <thead>
                    <tr>
                        <th style="width:50px">No</th>
                        <th>Nama item</th>
                        <th style="width:100px">Urutan</th>
                        <th style="width:90px">Aktif</th>
                        <th style="width:150px" class="text-end">Aksi</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $section->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <?php echo e($loop->iteration); ?>

                                <form method="POST" action="<?php echo e(route('control-items.items.update', $item)); ?>" id="item<?php echo e($item->id); ?>" class="d-none">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                </form>
                            </td>
                            <td><input type="text" name="name" form="item<?php echo e($item->id); ?>" value="<?php echo e($item->name); ?>" class="form-control form-control-sm"></td>
                            <td><input type="number" name="sort_order" form="item<?php echo e($item->id); ?>" value="<?php echo e($item->sort_order); ?>" class="form-control form-control-sm"></td>
                            <td>
                                <div class="form-check form-switch">
                                    <input type="checkbox" name="is_active" value="1" form="item<?php echo e($item->id); ?>" class="form-check-input" <?php if($item->is_active): echo 'checked'; endif; ?>>
                                </div>
                            </td>
                            <td class="text-end text-nowrap">
                                <button type="submit" form="item<?php echo e($item->id); ?>" class="btn btn-sm btn-outline-primary" title="Simpan">
                                    <i class="ti tabler-device-floppy"></i>
                                </button>
                                <button type="submit" form="delItem<?php echo e($item->id); ?>" class="btn btn-sm btn-outline-danger" title="Hapus"
                                        onclick="return confirm('Hapus item ini?');">
                                    <i class="ti tabler-trash"></i>
                                </button>
                                <form id="delItem<?php echo e($item->id); ?>" method="POST" action="<?php echo e(route('control-items.items.destroy', $item)); ?>" class="d-none">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="text-center text-body-secondary py-3">Belum ada item di bagian ini.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="card-body border-top">
                <form method="POST" action="<?php echo e(route('control-items.items.store', $section)); ?>" class="row g-2">
                    <?php echo csrf_field(); ?>
                    <div class="col-sm-9">
                        <input type="text" name="name" class="form-control form-control-sm" placeholder="Tambah item baru di bagian <?php echo e($section->code); ?>...">
                    </div>
                    <div class="col-sm-3">
                        <button type="submit" class="btn btn-sm btn-primary w-100"><i class="ti tabler-plus me-1"></i> Tambah Item</button>
                    </div>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\log-activity\resources\views/control-items/index.blade.php ENDPATH**/ ?>