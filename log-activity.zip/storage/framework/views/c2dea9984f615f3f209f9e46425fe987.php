<?php $__env->startSection('title', 'Detail Permohonan'); ?>
<?php $__env->startSection('page-title', 'Detail Permohonan Reset'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h6 class="mb-0"><?php echo e($resetRequest->name); ?> (<?php echo e($resetRequest->account_user_id); ?>)</h6>
            <span class="badge bg-label-<?php echo e($resetRequest->status->badgeColor()); ?>"><?php echo e($resetRequest->status->value); ?></span>
        </div>
        <div class="card-body">
            <div class="row g-4">
                <div class="col-md-4">
                    <p class="text-body-secondary mb-1">Tanggal Permohonan</p>
                    <p class="fw-medium"><?php echo e($resetRequest->requested_at->translatedFormat('d F Y')); ?></p>
                </div>
                <div class="col-md-4">
                    <p class="text-body-secondary mb-1">User ID</p>
                    <p class="fw-medium"><?php echo e($resetRequest->account_user_id); ?></p>
                </div>
                <div class="col-md-4">
                    <p class="text-body-secondary mb-1">Email</p>
                    <p class="fw-medium"><?php echo e($resetRequest->email); ?></p>
                </div>
                <div class="col-md-4">
                    <p class="text-body-secondary mb-1">Nama</p>
                    <p class="fw-medium"><?php echo e($resetRequest->name); ?></p>
                </div>
                <div class="col-12">
                    <p class="text-body-secondary mb-1">Jenis Permohonan</p>
                    <p class="fw-medium">
                        <?php $__currentLoopData = $resetRequest->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge bg-label-info me-1"><?php echo e($type); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </div>
                <div class="col-12">
                    <p class="text-body-secondary mb-1">Keterangan</p>
                    <p class="fw-medium" style="white-space: pre-line;"><?php echo e($resetRequest->notes ?: '-'); ?></p>
                </div>
            </div>
        </div>
        <div class="card-footer d-flex gap-2">
            <a href="<?php echo e(route('reset-requests.edit', $resetRequest)); ?>" class="btn btn-primary">
                <i class="ti tabler-edit me-1"></i> Edit
            </a>
            <a href="<?php echo e(route('reset-requests.index')); ?>" class="btn btn-outline-secondary">Kembali</a>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header">
            <h6 class="mb-0">Riwayat Perubahan Status</h6>
        </div>
        <div class="card-body">
            <ul class="list-unstyled mb-0">
                <?php $__empty_1 = true; $__currentLoopData = $resetRequest->activityLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="d-flex align-items-start mb-3 pb-3 <?php echo e(!$loop->last ? 'border-bottom' : ''); ?>">
                        <span class="avatar-initial rounded-circle bg-label-primary me-3" style="width:32px;height:32px;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                            <i class="ti tabler-history icon-sm"></i>
                        </span>
                        <div>
                            <div>
                                <?php if($log->old_status): ?>
                                    <span class="badge bg-label-secondary"><?php echo e($log->old_status); ?></span>
                                    <i class="ti tabler-arrow-right mx-1"></i>
                                <?php else: ?>
                                    <span class="text-body-secondary me-1">Dibuat dengan status</span>
                                <?php endif; ?>
                                <span class="badge bg-label-<?php echo e(\App\Enums\StatusEnum::from($log->new_status)->badgeColor()); ?>">
                                    <?php echo e($log->new_status); ?>

                                </span>
                            </div>
                            <div class="text-body-secondary small mt-1">
                                <?php echo e($log->user->name ?? 'Sistem'); ?> &middot; <?php echo e($log->created_at->translatedFormat('d F Y, H:i')); ?> WIB
                            </div>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="text-body-secondary">Belum ada riwayat perubahan.</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\log-activity\resources\views/reset-requests/show.blade.php ENDPATH**/ ?>