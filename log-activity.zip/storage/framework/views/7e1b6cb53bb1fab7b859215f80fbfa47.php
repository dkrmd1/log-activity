<?php $__env->startSection('title', 'Tambah Permintaan'); ?>
<?php $__env->startSection('page-title', 'Tambah Permintaan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('requests.store')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo $__env->make('requests._form', ['request' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="ti tabler-device-floppy me-1"></i> Simpan
                    </button>
                    <a href="<?php echo e(route('requests.index')); ?>" class="btn btn-outline-secondary">Batal</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\log-activity\resources\views/requests/create.blade.php ENDPATH**/ ?>