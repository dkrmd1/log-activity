<?php $__env->startSection('title', 'Form Kontrol Server & Jaringan'); ?>
<?php $__env->startSection('page-title', 'Kontrol Server & Jaringan'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .sc-table th, .sc-table td { vertical-align: middle; }
    .sc-table .cond { min-width: 78px; }
    .sc-table .note { min-width: 170px; }
    .sc-table .sec-row td { background: rgba(105,108,255,.10); font-weight: 600; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <?php
        // Staf mengisi form (Paraf = tanda tangan staf). Group Head hanya menandatangani. Admin hanya melihat.
        $canFill = auth()->user()->isStaff();
    ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
            <div>
                <h6 class="mb-0">Tanggal, <?php echo e($check->date_label); ?></h6>
                <?php if($canFill): ?>
                    <small class="text-body-secondary">Isi kolom Kondisi &amp; Keterangan sesuai waktu pemeriksaan. Paraf terisi otomatis dari tanda tangan Anda.</small>
                <?php else: ?>
                    <small class="text-body-secondary">Hanya Staf yang dapat mengisi form ini. Kolom Paraf terisi dari tanda tangan staf yang mengisi.</small>
                <?php endif; ?>
            </div>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-outline-primary btn-sm"
                        data-bs-toggle="modal" data-bs-target="#previewModal"
                        data-preview-url="<?php echo e(route('server-checks.preview', $check)); ?>">
                    <i class="ti tabler-eye me-1"></i> Lihat
                </button>
                <a href="<?php echo e(route('server-checks.pdf', $check)); ?>" class="btn btn-outline-danger btn-sm">
                    <i class="ti tabler-file-type-pdf me-1"></i> PDF
                </a>
                <a href="<?php echo e(route('server-checks.index')); ?>" class="btn btn-outline-secondary btn-sm">Kembali</a>
            </div>
        </div>

        <form method="POST" action="<?php echo e(route('server-checks.update', $check)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="table-responsive">
                <table class="table table-bordered table-sm sc-table mb-0">
                    <thead>
                    <tr class="table-light">
                        <th rowspan="2" class="text-center" style="width:44px">No</th>
                        <th rowspan="2" colspan="2">Item</th>
                        <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th colspan="2" class="text-center">
                                <?php echo e($label); ?>

                                <?php if($canFill): ?>
                                    <button type="button" class="btn btn-outline-success ms-1 js-all-ok" style="padding:0 .45rem; font-size:.7rem;" data-slot="<?php echo e($n); ?>"
                                            title="Isi semua Kondisi yang masih kosong dengan OK">Semua OK</button>
                                <?php endif; ?>
                            </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th rowspan="2" class="text-center" style="width:130px">Paraf</th>
                    </tr>
                    <tr class="table-light">
                        <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="text-center">Kondisi</th>
                            <th class="text-center">Keterangan</th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $first = $rows->first();
                            $count = $rows->count();
                        ?>
                        <tr class="sec-row">
                            <td class="text-center" rowspan="<?php echo e($count + 1); ?>"><?php echo e($code); ?></td>
                            <td colspan="9"><?php echo e($first->section_title); ?></td>
                        </tr>
                        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ri => $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($e->item_no); ?></td>
                                <td><?php echo e($e->item_name); ?></td>
                                <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td class="cond">
                                        <select name="entries[<?php echo e($e->id); ?>][c<?php echo e($n); ?>]" class="form-select form-select-sm js-cond" data-slot="<?php echo e($n); ?>" <?php if(! $canFill): echo 'disabled'; endif; ?>>
                                            <option value=""></option>
                                            <?php $__currentLoopData = \App\Models\ServerCheckEntry::CONDITIONS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($opt); ?>" <?php if($e->{'c' . $n} === $opt): echo 'selected'; endif; ?>><?php echo e($opt); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>
                                    <?php if($first->merge_notes): ?>
                                        <?php if($ri === 0): ?>
                                            <td class="note" rowspan="<?php echo e($count); ?>">
                                                <textarea name="entries[<?php echo e($e->id); ?>][n<?php echo e($n); ?>]" rows="<?php echo e(min(max($count, 3), 10)); ?>"
                                                          class="form-control form-control-sm" <?php if(! $canFill): echo 'disabled'; endif; ?>
                                                          placeholder="Keterangan <?php echo e($label); ?> (satu untuk seluruh bagian <?php echo e($code); ?>)"><?php echo e($e->{'n' . $n}); ?></textarea>
                                            </td>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <td class="note">
                                            <textarea name="entries[<?php echo e($e->id); ?>][n<?php echo e($n); ?>]" rows="2"
                                                      class="form-control form-control-sm" <?php if(! $canFill): echo 'disabled'; endif; ?>
                                                      placeholder="Keterangan"><?php echo e($e->{'n' . $n}); ?></textarea>
                                        </td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td class="text-center small"><?php echo e($e->parafUser?->name ?? '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php $__errorArgs = ['entries.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small px-4 pt-3"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="card-body">
                <?php if($canFill): ?>
                    <button type="submit" class="btn btn-primary">
                        <i class="ti tabler-device-floppy me-1"></i> Simpan
                    </button>
                <?php endif; ?>
                <a href="<?php echo e(route('server-checks.index')); ?>" class="btn btn-outline-secondary">Kembali</a>
            </div>
        </form>
    </div>

    
    <div class="card mt-4">
        <div class="card-header"><h6 class="mb-0">Tanda Tangan Group Head</h6></div>
        <div class="card-body">
            <?php if($check->isSigned()): ?>
                <div class="d-flex flex-wrap align-items-center gap-4">
                    <div class="border rounded p-2 bg-white">
                        <img src="<?php echo e($check->signed_signature_uri); ?>" alt="Tanda tangan" style="max-height:80px; max-width:100%;">
                    </div>
                    <div>
                        <div class="fw-medium"><?php echo e($check->signed_name); ?></div>
                        <div class="small text-body-secondary">
                            Ditandatangani <?php echo e($check->signed_at->locale('id')->translatedFormat('d F Y, H:i')); ?>

                        </div>
                        <?php if(auth()->user()->isGroupHead()): ?>
                            <form method="POST" action="<?php echo e(route('server-checks.unsign', $check)); ?>" class="mt-2"
                                  onsubmit="return confirm('Batalkan tanda tangan form ini?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger">Batalkan Tanda Tangan</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
                <p class="text-body-secondary small mt-3 mb-0">
                    Kalau isi form diubah setelah ini, tanda tangan otomatis dihapus dan Group Head perlu menandatangani ulang.
                </p>
            <?php elseif(auth()->user()->isGroupHead()): ?>
                <p class="text-body-secondary">
                    Blok nama &amp; tanda tangan di kanan bawah PDF hanya diisi oleh <strong>Group Head</strong>.
                    Klik tombol di bawah untuk menandatangani form tanggal ini dengan tanda tangan Anda.
                </p>
                <?php if(! auth()->user()->signature): ?>
                    <div class="alert alert-warning py-2">
                        Tanda tangan Anda belum diisi. <a href="<?php echo e(route('profile.edit')); ?>" class="alert-link">Isi di Profil Saya</a> dulu.
                    </div>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('server-checks.sign', $check)); ?>"
                      onsubmit="return confirm('Tanda tangani form tanggal <?php echo e($check->date_label); ?>?');">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-success" <?php if(! auth()->user()->signature): echo 'disabled'; endif; ?>>
                        <i class="ti tabler-signature me-1"></i> Tanda Tangani Form
                    </button>
                </form>
            <?php else: ?>
                <p class="text-body-secondary mb-0">
                    Form ini belum ditandatangani. Blok tanda tangan di kanan bawah PDF hanya diisi oleh Group Head,
                    jadi dibiarkan kosong sampai Group Head menandatangani.
                </p>
            <?php endif; ?>
        </div>
    </div>

    <?php echo $__env->make('server-checks._preview_modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.querySelectorAll('.js-all-ok').forEach(function (btn) {
    btn.addEventListener('click', function () {
        var slot = btn.getAttribute('data-slot');
        document.querySelectorAll('select.js-cond[data-slot="' + slot + '"]').forEach(function (sel) {
            if (sel.value === '') sel.value = 'OK';
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\log-activity\resources\views/server-checks/edit.blade.php ENDPATH**/ ?>