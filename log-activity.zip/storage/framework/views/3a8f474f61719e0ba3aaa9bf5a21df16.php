<?php $__env->startSection('title', 'Log Permintaan'); ?>
<?php $__env->startSection('page-title', 'Log Permintaan'); ?>

<?php $__env->startSection('content'); ?>

    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('requests.index')); ?>" class="row g-3 align-items-end">
                <div class="col-sm-6 col-md-3">
                    <label class="form-label">Cari Permintaan</label>
                    <input type="text" name="cari" value="<?php echo e($filters['cari'] ?? ''); ?>" class="form-control" placeholder="Judul permintaan...">
                </div>
                <div class="col-sm-6 col-md-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="">Semua Status</option>
                        <?php $__currentLoopData = $statusOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($status); ?>" <?php if(($filters['status'] ?? '') === $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-sm-6 col-md-3">
                    <label class="form-label">Bulan</label>
                    <input type="text" name="bulan" value="<?php echo e($filters['bulan'] ?? ''); ?>" class="form-control" placeholder='contoh: "Juli 2026"'>
                </div>
                <div class="col-sm-6 col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-primary flex-grow-1">
                        <i class="ti tabler-filter me-1"></i> Filter
                    </button>
                    <a href="<?php echo e(route('requests.index')); ?>" class="btn btn-outline-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
            <h6 class="mb-0">Daftar Permintaan</h6>
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('requests.export.excel', $filters)); ?>" class="btn btn-outline-success btn-sm">
                    <i class="ti tabler-file-spreadsheet me-1"></i> Export Excel
                </a>
                <a href="<?php echo e(route('requests.export.pdf', $filters)); ?>" class="btn btn-outline-danger btn-sm">
                    <i class="ti tabler-file-type-pdf me-1"></i> Export PDF
                </a>
                <a href="<?php echo e(route('requests.create')); ?>" class="btn btn-primary btn-sm">
                    <i class="ti tabler-plus me-1"></i> Tambah Permintaan
                </a>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal Terjadi</th>
                    <th>Kategori</th>
                    <th>Permintaan</th>
                    <th>Pemohon</th>
                    <th>Status</th>
                    <th class="text-end">Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration + ($requests->currentPage() - 1) * $requests->perPage()); ?></td>
                        <td><?php echo e($item->occurred_at->format('d/m/Y')); ?></td>
                        <td><?php echo e($item->category); ?></td>
                        <td><?php echo e(\Illuminate\Support\Str::limit($item->title, 40)); ?></td>
                        <td><?php echo e($item->requester); ?></td>
                        <td>
                            <span class="badge bg-label-<?php echo e($item->status->badgeColor()); ?>">
                                <?php echo e($item->status->value); ?>

                            </span>
                        </td>
                        <td class="text-end">
                            <a href="<?php echo e(route('requests.show', $item)); ?>" class="btn btn-icon btn-text-secondary" title="Lihat">
                                <i class="ti tabler-eye"></i>
                            </a>
                            <a href="<?php echo e(route('requests.edit', $item)); ?>" class="btn btn-icon btn-text-secondary" title="Edit">
                                <i class="ti tabler-edit"></i>
                            </a>
                            <form action="<?php echo e(route('requests.destroy', $item)); ?>" method="POST" class="d-inline"
                                  onsubmit="return confirm('Yakin hapus permintaan ini?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-icon btn-text-danger" title="Hapus">
                                    <i class="ti tabler-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-body-secondary py-4">
                            Belum ada data permintaan. Klik "Tambah Permintaan" untuk mulai mencatat.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($requests->hasPages()): ?>
            <div class="card-footer">
                <?php echo e($requests->links('pagination::bootstrap-5')); ?>

            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\log-activity\resources\views/requests/index.blade.php ENDPATH**/ ?>