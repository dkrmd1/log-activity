<?php $__env->startSection('title', 'Kontrol Server & Jaringan'); ?>
<?php $__env->startSection('page-title', 'Kontrol Server & Jaringan'); ?>

<?php $__env->startSection('content'); ?>

    <?php $canFill = auth()->user()->isStaff(); ?>

    <div class="row g-4 mb-4">
        <div class="col-lg-5">
            <div class="card h-100">
                <div class="card-header"><h6 class="mb-0">Buat Form Baru</h6></div>
                <div class="card-body">
                    <?php if($canFill): ?>
                        <form method="POST" action="<?php echo e(route('server-checks.store')); ?>" class="row g-2 align-items-end">
                            <?php echo csrf_field(); ?>
                            <div class="col">
                                <label class="form-label">Tanggal</label>
                                <input type="date" name="check_date" value="<?php echo e(old('check_date', now()->format('Y-m-d'))); ?>"
                                       class="form-control <?php $__errorArgs = ['check_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['check_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-auto">
                                <button type="submit" class="btn btn-primary">
                                    <i class="ti tabler-plus me-1"></i> Buat / Buka Form
                                </button>
                            </div>
                        </form>
                        <p class="text-body-secondary small mb-0 mt-2">
                            Satu form per tanggal, berisi pemeriksaan pukul <?php echo e(implode(', ', $slots)); ?>.
                            Kalau form tanggal itu sudah ada, langsung dibuka.
                        </p>
                    <?php else: ?>
                        <p class="text-body-secondary mb-0">
                            Form harian dibuat dan diisi oleh <strong>Staf</strong>
                            (kolom Paraf memakai tanda tangan staf yang mengisi).
                            <?php if(auth()->user()->isGroupHead()): ?>
                                Sebagai Group Head, Anda menandatangani form yang sudah terisi lewat tombol
                                <em>Lihat / Tanda Tangani</em> pada riwayat di bawah.
                            <?php endif; ?>
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="card h-100">
                <div class="card-header"><h6 class="mb-0">Filter</h6></div>
                <div class="card-body">
                    <form method="GET" action="<?php echo e(route('server-checks.index')); ?>" class="row g-2 align-items-end">
                        <div class="col-sm-6">
                            <label class="form-label">Bulan</label>
                            <input type="text" name="bulan" value="<?php echo e($bulan); ?>" class="form-control" placeholder='contoh: "September 2026"'>
                        </div>
                        <div class="col-sm-6 d-flex gap-2">
                            <button type="submit" class="btn btn-primary flex-grow-1"><i class="ti tabler-filter me-1"></i> Filter</button>
                            <a href="<?php echo e(route('server-checks.index')); ?>" class="btn btn-outline-secondary">Reset</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><h6 class="mb-0">Riwayat Form Kontrol</h6></div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th>Tanggal</th>
                    <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="text-center"><?php echo e($label); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th>Petugas</th>
                    <th>Tanda Tangan</th>
                    <th class="text-end">Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $checks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $total = $check->entries->count();
                        $filled = $check->filledCounts();
                        $petugas = $check->entries->pluck('parafUser.name')->filter()->unique()->implode(', ');
                    ?>
                    <tr>
                        <td><?php echo e($check->date_label); ?></td>
                        <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="text-center">
                                <span class="badge bg-label-<?php echo e($filled[$n] === 0 ? 'secondary' : ($filled[$n] >= $total ? 'success' : 'warning')); ?>">
                                    <?php echo e($filled[$n]); ?>/<?php echo e($total); ?>

                                </span>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($petugas ?: '-'); ?></td>
                        <td>
                            <?php if($check->isSigned()): ?>
                                <span class="badge bg-label-success" title="<?php echo e($check->signed_name); ?>">Sudah &middot; <?php echo e($check->signed_name); ?></span>
                            <?php else: ?>
                                <span class="badge bg-label-secondary">Belum</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-end text-nowrap">
                            <a href="<?php echo e(route('server-checks.edit', $check)); ?>" class="btn btn-icon btn-text-secondary" title="<?php echo e($canFill ? 'Isi / Edit' : (auth()->user()->isGroupHead() ? 'Lihat / Tanda Tangani' : 'Lihat')); ?>">
                                <i class="ti tabler-edit"></i>
                            </a>
                            <button type="button" class="btn btn-icon btn-text-primary" title="Lihat"
                                    data-bs-toggle="modal" data-bs-target="#previewModal"
                                    data-preview-url="<?php echo e(route('server-checks.preview', $check)); ?>">
                                <i class="ti tabler-eye"></i>
                            </button>
                            <a href="<?php echo e(route('server-checks.pdf', $check)); ?>" class="btn btn-icon btn-text-danger" title="Download PDF">
                                <i class="ti tabler-file-type-pdf"></i>
                            </a>
                            <form action="<?php echo e(route('server-checks.destroy', $check)); ?>" method="POST" class="d-inline"
                                  onsubmit="return confirm('Hapus form kontrol tanggal <?php echo e($check->date_label); ?>?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-icon btn-text-danger" title="Hapus">
                                    <i class="ti tabler-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="<?php echo e(count($slots) + 4); ?>" class="text-center text-body-secondary py-4">
                            Belum ada form kontrol. Pilih tanggal di atas lalu klik "Buat / Buka Form".
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($checks->hasPages()): ?>
            <div class="card-footer">
                <?php echo e($checks->links('pagination::bootstrap-5')); ?>

            </div>
        <?php endif; ?>
    </div>

    <?php echo $__env->make('server-checks._preview_modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\log-activity\resources\views/server-checks/index.blade.php ENDPATH**/ ?>