<?php $__env->startSection('title', 'Kelola Kategori'); ?>
<?php $__env->startSection('page-title', 'Kelola Kategori & Pilihan'); ?>

<?php $__env->startSection('content'); ?>

    <ul class="nav nav-pills mb-4">
        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e($type === $key ? 'active' : ''); ?>" href="<?php echo e(route('categories.index', ['type' => $key])); ?>"><?php echo e($label); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <div class="card mb-4">
        <div class="card-header">
            <h6 class="mb-0">Tambah <?php echo e($types[$type]); ?> Baru</h6>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('categories.store')); ?>" class="row g-3 align-items-start">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="type" value="<?php echo e($type); ?>">
                <div class="col-sm-8 col-md-6">
                    <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           placeholder="Ketik nama baru...">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-primary">
                        <i class="ti tabler-plus me-1"></i> Tambah
                    </button>
                </div>
            </form>
            <p class="text-body-secondary small mb-0 mt-2">
                <?php switch($type):
                    case ('isu'): ?> Setelah ditambah, langsung muncul sebagai pilihan di form "Tambah Isu" / "Edit Isu". <?php break; ?>
                    <?php case ('permintaan'): ?> Setelah ditambah, langsung muncul sebagai pilihan di form "Tambah Permintaan" / "Edit Permintaan". <?php break; ?>
                    <?php case ('backup'): ?> Setelah ditambah, langsung muncul di form "Catat Backup" dan di tabel Status Backup. <?php break; ?>
                <?php endswitch; ?>
            </p>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h6 class="mb-0">Daftar <?php echo e($types[$type]); ?> (<?php echo e($categories->count()); ?>)</h6>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th style="width:5%">No</th>
                    <th>Nama</th>
                    <th style="width:140px">Dipakai</th>
                    <th class="text-end" style="width:120px">Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($i + 1); ?></td>
                        <td>
                            <form method="POST" action="<?php echo e(route('categories.update', $category)); ?>" class="d-flex gap-2">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <input type="hidden" name="type" value="<?php echo e($category->type); ?>">
                                <input type="text" name="name" value="<?php echo e($category->name); ?>" class="form-control form-control-sm" style="max-width:320px;">
                                <button type="submit" class="btn btn-sm btn-outline-primary" title="Simpan perubahan nama">
                                    <i class="ti tabler-device-floppy"></i>
                                </button>
                            </form>
                        </td>
                        <td>
                            <span class="badge bg-label-<?php echo e($usage[$category->id] > 0 ? 'info' : 'secondary'); ?>"><?php echo e($usage[$category->id]); ?> data</span>
                        </td>
                        <td class="text-end">
                            <?php if($usage[$category->id] > 0): ?>
                                <button type="button" class="btn btn-icon btn-text-secondary" disabled
                                        title="Masih dipakai di data, tidak bisa dihapus">
                                    <i class="ti tabler-trash"></i>
                                </button>
                            <?php else: ?>
                                <form action="<?php echo e(route('categories.destroy', $category)); ?>" method="POST" class="d-inline"
                                      onsubmit="return confirm('Yakin hapus &quot;<?php echo e(addslashes($category->name)); ?>&quot;?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-icon btn-text-danger" title="Hapus">
                                        <i class="ti tabler-trash"></i>
                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="text-center text-body-secondary py-4">
                            Belum ada data. Tambahkan lewat form di atas.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\log-activity\resources\views/categories/index.blade.php ENDPATH**/ ?>